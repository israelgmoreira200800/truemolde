# MoldeTrue

Projeto-fonte Windows em Python 3.11+ para adaptar o cliente a novas matérias.

## Comandos

- Preparar: `powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1`
- Executar: `powershell -ExecutionPolicy Bypass -File .\scripts\run.ps1 -Subject nova-materia`
- Testar: `.\.venv\Scripts\python.exe -m unittest discover -s tests -v`
- Verificar sintaxe: `.\.venv\Scripts\python.exe -m compileall -q src tests`

## Convenções

- O ponto de entrada é `src/molde_true/__main__.py`.
- Configurações públicas ficam em `config.toml`; segredos entram somente por variáveis de ambiente.
- Nunca inclua a chave SSH no repositório. Use `MOLDETRUE_SSH_KEY` com o caminho para uma chave externa.
- O projeto permanece em código-fonte. Não adicione executáveis, bytecode, logs ou capturas de tela.

