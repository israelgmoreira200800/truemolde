from __future__ import annotations

import os
import re
import tomllib
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


def _as_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "sim", "on"}


def subject_slug(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value.strip().lower())
    ascii_value = normalized.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", "-", ascii_value).strip("-")
    if not slug or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", slug):
        raise ValueError("A matéria precisa ter letras, números ou hífens.")
    return slug


@dataclass(frozen=True)
class TunnelSettings:
    enabled: bool = False
    ssh_host: str = ""
    ssh_user: str = ""
    key_path: Path | None = None
    local_port: int = 3000
    remote_host: str = "127.0.0.1"
    remote_port: int = 5000

    def validate(self) -> None:
        for name, port in (("local_port", self.local_port), ("remote_port", self.remote_port)):
            if not 1 <= port <= 65535:
                raise ValueError(f"{name} deve estar entre 1 e 65535.")
        if self.enabled:
            if not self.ssh_host or not self.ssh_user:
                raise ValueError("Túnel ativo exige ssh_host e ssh_user.")
            if self.key_path is None or not self.key_path.is_file():
                raise ValueError("Túnel ativo exige uma chave existente em MOLDETRUE_SSH_KEY.")


@dataclass(frozen=True)
class Settings:
    subject: str
    base_url: str = "http://127.0.0.1:3000"
    connect_timeout: float = 3.0
    read_timeout: float = 90.0
    answer_duration_ms: int = 2200
    status_duration_ms: int = 1500
    save_last_screenshot: bool = False
    data_dir: Path = Path(".")
    tunnel: TunnelSettings = TunnelSettings()

    @property
    def answer_url(self) -> str:
        return f"{self.base_url}/answer"

    @property
    def health_url(self) -> str:
        return f"{self.base_url}/health"

    def validate(self) -> None:
        parsed = urlparse(self.base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("base_url deve ser uma URL HTTP válida.")
        if self.connect_timeout <= 0 or self.read_timeout <= 0:
            raise ValueError("Os tempos limite devem ser positivos.")
        if self.answer_duration_ms <= 0 or self.status_duration_ms <= 0:
            raise ValueError("As durações da interface devem ser positivas.")
        self.tunnel.validate()

    @classmethod
    def load(cls, path: Path, subject_override: str | None = None) -> "Settings":
        raw: dict[str, Any] = {}
        if path.is_file():
            with path.open("rb") as stream:
                raw = tomllib.load(stream)

        app = raw.get("app", {})
        tunnel = raw.get("tunnel", {})
        subject = subject_slug(
            subject_override
            or os.getenv("MOLDETRUE_SUBJECT")
            or str(app.get("subject", "nova-materia"))
        )

        local_app_data = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        data_dir = Path(
            os.getenv("MOLDETRUE_DATA_DIR")
            or str(app.get("data_dir") or local_app_data / "MoldeTrue" / subject)
        ).expanduser()

        key_value = os.getenv("MOLDETRUE_SSH_KEY") or tunnel.get("key_path")
        key_path = Path(str(key_value)).expanduser() if key_value else None

        settings = cls(
            subject=subject,
            base_url=(os.getenv("MOLDETRUE_BASE_URL") or str(app.get("base_url", "http://127.0.0.1:3000"))).rstrip("/"),
            connect_timeout=float(app.get("connect_timeout", 3.0)),
            read_timeout=float(app.get("read_timeout", 90.0)),
            answer_duration_ms=int(app.get("answer_duration_ms", 2200)),
            status_duration_ms=int(app.get("status_duration_ms", 1500)),
            save_last_screenshot=_as_bool(
                os.getenv("MOLDETRUE_SAVE_SCREENSHOT", app.get("save_last_screenshot", False))
            ),
            data_dir=data_dir,
            tunnel=TunnelSettings(
                enabled=_as_bool(os.getenv("MOLDETRUE_TUNNEL_ENABLED", tunnel.get("enabled", False))),
                ssh_host=os.getenv("MOLDETRUE_SSH_HOST") or str(tunnel.get("ssh_host", "")),
                ssh_user=os.getenv("MOLDETRUE_SSH_USER") or str(tunnel.get("ssh_user", "")),
                key_path=key_path,
                local_port=int(tunnel.get("local_port", 3000)),
                remote_host=str(tunnel.get("remote_host", "127.0.0.1")),
                remote_port=int(tunnel.get("remote_port", 5000)),
            ),
        )
        settings.validate()
        return settings

