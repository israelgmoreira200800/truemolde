from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .app import StudyApp
from .config import Settings


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Cliente de captura configurável por matéria")
    parser.add_argument("--subject", help="Identificador da matéria, por exemplo: fisica")
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("config.toml"),
        help="Arquivo TOML de configuração",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if sys.platform != "win32":
        print("Este cliente usa atalhos globais e captura de tela do Windows.", file=sys.stderr)
        return 2

    try:
        settings = Settings.load(args.config, subject_override=args.subject)
        return StudyApp(settings).run()
    except (OSError, RuntimeError, ValueError) as error:
        print(f"Falha ao iniciar: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

