from __future__ import annotations

import ctypes
import logging
import logging.handlers
import queue
import threading
import time
import tkinter as tk
from collections.abc import Callable

import requests
from PIL import Image

from .api import ApiClient
from .capture import capture_current_monitor, save_last_screenshot
from .config import Settings
from .hotkeys import WindowsHotkeys
from .tunnel import TunnelManager
from .ui import StatusWindow

PRINT_ERROR = "ERP"
QUESTION_ERROR = "ERQ"


class StudyApp:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        self.logger = self._build_logger()
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.geometry("1x1+-32000+-32000")
        self.root.attributes("-alpha", 0.0)
        self.root.protocol("WM_DELETE_WINDOW", self.request_exit)
        self.status = StatusWindow(self.root)
        self.api = ApiClient(settings)
        self.tunnel = TunnelManager(settings.tunnel, self.api)
        self.events: queue.SimpleQueue[tuple[str, object]] = queue.SimpleQueue()
        self.hotkeys = WindowsHotkeys(self._queue_action)
        self.busy = False
        self.capture_generation = 0
        self.last_hotkey_at = 0.0
        self.exiting = False
        self._mutex = None

    def _build_logger(self) -> logging.Logger:
        logger = logging.getLogger(f"molde_true.{self.settings.subject}")
        logger.setLevel(logging.INFO)
        logger.propagate = False
        if not logger.handlers:
            handler = logging.handlers.RotatingFileHandler(
                self.settings.data_dir / "debug.log",
                maxBytes=120_000,
                backupCount=1,
                encoding="utf-8",
            )
            handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
            logger.addHandler(handler)
        return logger

    def _acquire_single_instance(self) -> bool:
        kernel32 = ctypes.windll.kernel32
        kernel32.CreateMutexW.restype = ctypes.c_void_p
        name = f"Local\\MoldeTrue-{self.settings.subject}"
        self._mutex = kernel32.CreateMutexW(None, False, name)
        return bool(self._mutex) and kernel32.GetLastError() != 183

    def run(self) -> int:
        if not self._acquire_single_instance():
            self.logger.info("Outra instância da matéria já está ativa.")
            return 0
        self.logger.info("Início subject=%s", self.settings.subject)
        try:
            self.hotkeys.install()
            self.root.after(30, self._pump)
            self.root.after(100, lambda: self.status.show("ON", self.settings.status_duration_ms))
            self.root.mainloop()
            return 0
        finally:
            self.hotkeys.uninstall()
            self.tunnel.stop()
            self.api.close()
            self.logger.info("Fim")

    def _queue_action(self, action: str, source: str) -> None:
        self.events.put(("action", (action, source)))

    def _queue_call(self, callback: Callable[[], None]) -> None:
        self.events.put(("call", callback))

    def _pump(self) -> None:
        try:
            self.hotkeys.pump_registered()
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "action":
                    action, source = payload  # type: ignore[misc]
                    self._dispatch_action(str(action), str(source))
                elif kind == "call" and callable(payload):
                    payload()
        except queue.Empty:
            pass
        except Exception:
            self.logger.exception("Falha ao processar fila")
        finally:
            if not self.exiting:
                self.root.after(30, self._pump)

    def _dispatch_action(self, action: str, source: str) -> None:
        now = time.monotonic()
        if now - self.last_hotkey_at < 0.4:
            return
        self.last_hotkey_at = now
        self.logger.info("Hotkey %s via %s", action, source)
        if action == "answer":
            self.start_capture()
        elif action == "api":
            self.start_api_check()
        elif action == "quit":
            self.request_exit()

    def request_exit(self) -> None:
        if self.exiting:
            return
        self.exiting = True
        self.logger.info("Encerramento solicitado")
        self.root.after(0, self.root.destroy)

    def start_api_check(self) -> None:
        threading.Thread(target=self._check_api, daemon=True, name="api-check").start()

    def _check_api(self) -> None:
        try:
            ok = self.api.health_ok() or self.tunnel.ensure()
            text = "API OK" if ok else "API FALHOU"
            duration = self.settings.status_duration_ms if ok else 2000
            self._queue_call(lambda: self.status.show(text, duration))
        except Exception:
            self.logger.exception("Falha ao verificar API")
            self._queue_call(lambda: self.status.show("API FALHOU", 2000))

    def start_capture(self) -> None:
        if self.busy:
            self.logger.info("Captura ignorada: requisição em andamento")
            return
        self.busy = True
        self.capture_generation += 1
        generation = self.capture_generation
        self.status.hide()
        self.root.after(80, lambda: self._capture(generation))

    def _capture(self, generation: int) -> None:
        if generation != self.capture_generation:
            return
        try:
            image = capture_current_monitor()
            if self.settings.save_last_screenshot:
                save_last_screenshot(image, self.settings.data_dir)
            threading.Thread(
                target=self._send_image,
                args=(image, generation),
                daemon=True,
                name="answer-request",
            ).start()
            self.root.after(100_000, lambda: self._release_if_stuck(generation))
        except Exception:
            self.busy = False
            self.logger.exception("Falha de captura")
            self.status.show(PRINT_ERROR, 2000)

    def _send_image(self, image: Image.Image, generation: int) -> None:
        try:
            try:
                answer = self.api.send_image(image)
            except requests.RequestException:
                if not self.tunnel.ensure():
                    raise
                answer = self.api.send_image(image)
            self._queue_call(lambda: self.status.show(answer, self.settings.answer_duration_ms))
        except (requests.RequestException, ValueError, OSError):
            self.logger.exception("Falha ao obter resposta")
            self._queue_call(lambda: self.status.show(QUESTION_ERROR, 2000))
        finally:
            if generation == self.capture_generation:
                self.busy = False

    def _release_if_stuck(self, generation: int) -> None:
        if generation == self.capture_generation and self.busy:
            self.busy = False
            self.logger.warning("Estado ocupado liberado por tempo limite")

