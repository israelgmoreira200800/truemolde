from __future__ import annotations

import ctypes
import tkinter as tk
from ctypes import wintypes


def cursor_position() -> tuple[int, int]:
    point = wintypes.POINT()
    if not ctypes.windll.user32.GetCursorPos(ctypes.byref(point)):
        return 0, 0
    return int(point.x), int(point.y)


class StatusWindow:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.window: tk.Toplevel | None = None
        self.label: tk.Label | None = None
        self.hide_job: str | None = None

    def _ensure(self) -> None:
        if self.window is not None:
            return
        window = tk.Toplevel(self.root)
        window.overrideredirect(True)
        window.attributes("-topmost", True)
        try:
            window.attributes("-toolwindow", True)
        except tk.TclError:
            pass
        window.configure(bg="white")
        window.protocol("WM_DELETE_WINDOW", lambda: None)
        label = tk.Label(
            window,
            text="",
            bg="white",
            fg="black",
            font=("Segoe UI", 8),
            padx=8,
            pady=5,
            justify="left",
        )
        label.pack()
        window.withdraw()
        self.window = window
        self.label = label

    def show(self, text: str, duration_ms: int) -> None:
        self._ensure()
        assert self.window is not None and self.label is not None
        self.label.config(text=text)
        self.window.update_idletasks()
        x, y = cursor_position()
        width = self.window.winfo_reqwidth()
        height = self.window.winfo_reqheight()
        screen_width = self.window.winfo_screenwidth()
        screen_height = self.window.winfo_screenheight()
        x = min(max(0, x + 12), max(0, screen_width - width))
        y = min(max(0, y + 12), max(0, screen_height - height))
        self.window.geometry(f"+{x}+{y}")
        self.window.deiconify()
        self.window.lift()
        self.window.attributes("-topmost", True)
        if self.hide_job:
            self.root.after_cancel(self.hide_job)
        self.hide_job = self.root.after(duration_ms, self.hide)

    def hide(self) -> None:
        self.hide_job = None
        if self.window is not None:
            self.window.withdraw()

