from __future__ import annotations

import base64

import requests
from PIL import Image

from .capture import encode_jpeg
from .config import Settings


class ApiClient:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.session = requests.Session()

    def health_ok(self) -> bool:
        try:
            response = self.session.get(
                self.settings.health_url,
                timeout=self.settings.connect_timeout,
            )
            return response.status_code < 300
        except requests.RequestException:
            return False

    def send_image(self, image: Image.Image) -> str:
        payload = {
            "image": base64.b64encode(encode_jpeg(image)).decode("ascii"),
            "subject": self.settings.subject,
        }
        response = self.session.post(
            self.settings.answer_url,
            json=payload,
            timeout=(self.settings.connect_timeout, self.settings.read_timeout),
        )
        response.raise_for_status()
        body = response.json()
        if not isinstance(body, dict):
            raise ValueError("A API não retornou um objeto JSON.")
        for field in ("answer", "resposta", "question", "questao"):
            value = body.get(field)
            if value is not None and str(value).strip():
                return str(value).strip()
        raise ValueError("A API retornou uma resposta vazia.")

    def close(self) -> None:
        self.session.close()

