from __future__ import annotations

import os
import shutil
import subprocess
import threading
import time

from .api import ApiClient
from .config import TunnelSettings

CREATE_NO_WINDOW = 0x08000000


class TunnelManager:
    def __init__(self, settings: TunnelSettings, api: ApiClient) -> None:
        self.settings = settings
        self.api = api
        self.process: subprocess.Popen[bytes] | None = None
        self._lock = threading.RLock()

    def build_command(self) -> list[str]:
        ssh = shutil.which("ssh")
        if not ssh:
            raise FileNotFoundError("Cliente OpenSSH não encontrado no PATH.")
        assert self.settings.key_path is not None
        target = f"{self.settings.ssh_user}@{self.settings.ssh_host}"
        forward = (
            f"127.0.0.1:{self.settings.local_port}:"
            f"{self.settings.remote_host}:{self.settings.remote_port}"
        )
        return [
            ssh,
            "-N",
            "-L",
            forward,
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=5",
            "-o",
            "IdentitiesOnly=yes",
            "-o",
            "ExitOnForwardFailure=yes",
            "-o",
            "ServerAliveInterval=30",
            "-o",
            "ServerAliveCountMax=3",
            "-i",
            str(self.settings.key_path),
            target,
        ]

    def ensure(self, timeout: float = 25.0) -> bool:
        with self._lock:
            if self.api.health_ok():
                return True
            if not self.settings.enabled:
                return False
            self.stop()

            creation_flags = CREATE_NO_WINDOW if os.name == "nt" else 0
            self.process = subprocess.Popen(
                self.build_command(),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=creation_flags,
            )
            deadline = time.monotonic() + timeout
            while time.monotonic() < deadline:
                if self.process.poll() is not None:
                    return False
                if self.api.health_ok():
                    return True
                time.sleep(0.2)
            self.stop()
            return False

    def stop(self) -> None:
        with self._lock:
            if self.process is None or self.process.poll() is not None:
                self.process = None
                return
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()
            finally:
                self.process = None

