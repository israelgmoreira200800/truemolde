from __future__ import annotations

import ctypes
import io
from ctypes import wintypes
from pathlib import Path

from PIL import Image, ImageGrab

MONITOR_DEFAULTTONEAREST = 2


class Rect(ctypes.Structure):
    _fields_ = [
        ("left", wintypes.LONG),
        ("top", wintypes.LONG),
        ("right", wintypes.LONG),
        ("bottom", wintypes.LONG),
    ]


class MonitorInfo(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("rcMonitor", Rect),
        ("rcWork", Rect),
        ("dwFlags", wintypes.DWORD),
    ]


def current_monitor_rect() -> tuple[int, int, int, int]:
    point = wintypes.POINT()
    user32 = ctypes.windll.user32
    if not user32.GetCursorPos(ctypes.byref(point)):
        raise OSError("Não foi possível localizar o cursor.")

    user32.MonitorFromPoint.restype = wintypes.HMONITOR
    monitor = user32.MonitorFromPoint(point, MONITOR_DEFAULTTONEAREST)
    info = MonitorInfo()
    info.cbSize = ctypes.sizeof(MonitorInfo)
    if not monitor or not user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
        raise OSError("Não foi possível localizar o monitor atual.")
    rect = info.rcMonitor
    return int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)


def is_blank(image: Image.Image) -> bool:
    preview = image.copy()
    preview.thumbnail((40, 40))
    low, high = preview.convert("L").getextrema()
    return high - low <= 2


def capture_current_monitor() -> Image.Image:
    rect = current_monitor_rect()
    image = ImageGrab.grab(bbox=rect, all_screens=True)
    if is_blank(image):
        raise OSError("A captura do monitor veio vazia.")
    return image


def encode_jpeg(image: Image.Image, max_side: int = 2560) -> bytes:
    converted = image.convert("RGB")
    if max(converted.size) > max_side:
        converted = converted.copy()
        converted.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)
    buffer = io.BytesIO()
    converted.save(buffer, format="JPEG", quality=85, subsampling=1, optimize=False)
    return buffer.getvalue()


def save_last_screenshot(image: Image.Image, directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "last_screenshot.jpg").write_bytes(encode_jpeg(image))

