"""Cliente Windows configurável por matéria."""

__version__ = "0.1.0"

