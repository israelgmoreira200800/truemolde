from __future__ import annotations

import ctypes
from ctypes import wintypes
from dataclasses import dataclass
from typing import Callable

VK_CONTROL = 0x11
VK_SHIFT = 0x10
VK_MENU = 0x12
VK_LSHIFT = 0xA0
VK_RSHIFT = 0xA1
VK_LCONTROL = 0xA2
VK_RCONTROL = 0xA3
VK_LMENU = 0xA4
VK_RMENU = 0xA5
VK_O = 0x4F
VK_Q = 0x51

WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
WM_HOTKEY = 0x0312
PM_REMOVE = 0x0001
WH_KEYBOARD_LL = 13
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_NOREPEAT = 0x4000
HOTKEY_API = 2
HOTKEY_QUIT = 3

MODIFIER_KEYS = {
    VK_CONTROL,
    VK_SHIFT,
    VK_MENU,
    VK_LSHIFT,
    VK_RSHIFT,
    VK_LCONTROL,
    VK_RCONTROL,
    VK_LMENU,
    VK_RMENU,
}
CTRL_KEYS = {VK_CONTROL, VK_LCONTROL, VK_RCONTROL}
SHIFT_KEYS = {VK_SHIFT, VK_LSHIFT, VK_RSHIFT}


@dataclass
class HotkeyState:
    """Reconhece AltGr sozinho sem disparar quando ele modifica outra tecla."""

    altgr_down: bool = False
    altgr_used_with_key: bool = False

    def feed(self, vk_code: int, *, is_down: bool, is_up: bool) -> str | None:
        if vk_code == VK_RMENU:
            if is_down and not self.altgr_down:
                self.altgr_down = True
                self.altgr_used_with_key = False
            elif is_up and self.altgr_down:
                should_answer = not self.altgr_used_with_key
                self.altgr_down = False
                self.altgr_used_with_key = False
                return "answer" if should_answer else None
            return None

        if self.altgr_down and is_down and vk_code not in MODIFIER_KEYS:
            self.altgr_used_with_key = True
        return None


class KeyboardData(ctypes.Structure):
    _fields_ = [
        ("vkCode", wintypes.DWORD),
        ("scanCode", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class Message(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("message", wintypes.UINT),
        ("wParam", wintypes.WPARAM),
        ("lParam", wintypes.LPARAM),
        ("time", wintypes.DWORD),
        ("pt", wintypes.POINT),
    ]


LRESULT = ctypes.c_ssize_t
HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)


class WindowsHotkeys:
    def __init__(self, on_action: Callable[[str, str], None]) -> None:
        self.on_action = on_action
        self._state = HotkeyState()
        self._ctrl = False
        self._shift = False
        self._hook = None
        self._hook_proc = HOOKPROC(self._keyboard_hook)
        self._registered: list[int] = []

    def install(self) -> None:
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
        kernel32.GetModuleHandleW.restype = ctypes.c_void_p
        user32.SetWindowsHookExW.argtypes = [
            ctypes.c_int,
            HOOKPROC,
            ctypes.c_void_p,
            wintypes.DWORD,
        ]
        user32.SetWindowsHookExW.restype = ctypes.c_void_p
        user32.CallNextHookEx.argtypes = [
            ctypes.c_void_p,
            ctypes.c_int,
            wintypes.WPARAM,
            wintypes.LPARAM,
        ]
        user32.CallNextHookEx.restype = LRESULT
        self._hook = user32.SetWindowsHookExW(
            WH_KEYBOARD_LL,
            self._hook_proc,
            kernel32.GetModuleHandleW(None),
            0,
        )
        if not self._hook:
            raise OSError("Não foi possível instalar o gancho global de teclado.")

        modifiers = MOD_CONTROL | MOD_SHIFT | MOD_NOREPEAT
        for hotkey_id, key in ((HOTKEY_API, VK_O), (HOTKEY_QUIT, VK_Q)):
            if user32.RegisterHotKey(None, hotkey_id, modifiers, key):
                self._registered.append(hotkey_id)

    def uninstall(self) -> None:
        user32 = ctypes.windll.user32
        if self._hook:
            user32.UnhookWindowsHookEx(self._hook)
            self._hook = None
        for hotkey_id in self._registered:
            user32.UnregisterHotKey(None, hotkey_id)
        self._registered.clear()

    def _keyboard_hook(self, n_code: int, w_param: int, l_param: int) -> int:
        try:
            if n_code >= 0:
                data = ctypes.cast(l_param, ctypes.POINTER(KeyboardData)).contents
                vk_code = int(data.vkCode)
                message = int(w_param)
                is_down = message in {WM_KEYDOWN, WM_SYSKEYDOWN}
                is_up = message in {WM_KEYUP, WM_SYSKEYUP}

                if vk_code in CTRL_KEYS:
                    self._ctrl = is_down or (self._ctrl and not is_up)
                if vk_code in SHIFT_KEYS:
                    self._shift = is_down or (self._shift and not is_up)

                action = self._state.feed(vk_code, is_down=is_down, is_up=is_up)
                if action:
                    self.on_action(action, "hook")
                if is_down and self._ctrl and self._shift and vk_code == VK_O:
                    self.on_action("api", "hook")
                if is_down and self._ctrl and self._shift and vk_code == VK_Q:
                    self.on_action("quit", "hook")
        except Exception:
            # Uma exceção nunca pode interromper a cadeia global de hooks.
            pass
        return ctypes.windll.user32.CallNextHookEx(self._hook, n_code, w_param, l_param)

    def pump_registered(self) -> None:
        message = Message()
        user32 = ctypes.windll.user32
        while user32.PeekMessageW(ctypes.byref(message), None, WM_HOTKEY, WM_HOTKEY, PM_REMOVE):
            if int(message.wParam) == HOTKEY_API:
                self.on_action("api", "register")
            elif int(message.wParam) == HOTKEY_QUIT:
                self.on_action("quit", "register")

