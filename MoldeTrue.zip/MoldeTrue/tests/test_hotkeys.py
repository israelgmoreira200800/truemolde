from __future__ import annotations

import unittest

from molde_true.hotkeys import HotkeyState, VK_RMENU


class HotkeyStateTests(unittest.TestCase):
    def test_altgr_alone_requests_answer(self) -> None:
        state = HotkeyState()
        self.assertIsNone(state.feed(VK_RMENU, is_down=True, is_up=False))
        self.assertEqual(state.feed(VK_RMENU, is_down=False, is_up=True), "answer")

    def test_altgr_used_as_modifier_does_not_request_answer(self) -> None:
        state = HotkeyState()
        state.feed(VK_RMENU, is_down=True, is_up=False)
        state.feed(ord("Q"), is_down=True, is_up=False)
        self.assertIsNone(state.feed(VK_RMENU, is_down=False, is_up=True))


if __name__ == "__main__":
    unittest.main()

