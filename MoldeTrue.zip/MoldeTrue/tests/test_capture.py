from __future__ import annotations

import unittest

from PIL import Image

from molde_true.capture import encode_jpeg, is_blank


class CaptureTests(unittest.TestCase):
    def test_encodes_and_limits_largest_side(self) -> None:
        image = Image.new("RGB", (3000, 1000), "navy")
        content = encode_jpeg(image)
        self.assertTrue(content.startswith(b"\xff\xd8"))

    def test_detects_uniform_image(self) -> None:
        self.assertTrue(is_blank(Image.new("RGB", (100, 100), "white")))


if __name__ == "__main__":
    unittest.main()
