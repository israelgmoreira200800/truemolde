from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from molde_true.config import Settings, subject_slug


class ConfigTests(unittest.TestCase):
    def test_subject_slug_normalizes_portuguese_name(self) -> None:
        self.assertEqual(subject_slug("  Física Aplicada  "), "fisica-aplicada")

    def test_environment_overrides_toml(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            config = Path(directory) / "config.toml"
            config.write_text(
                '[app]\nsubject = "matematica"\nbase_url = "http://127.0.0.1:3000"\n',
                encoding="utf-8",
            )
            with patch.dict(os.environ, {"MOLDETRUE_SUBJECT": "Química"}, clear=False):
                settings = Settings.load(config)
            self.assertEqual(settings.subject, "quimica")


if __name__ == "__main__":
    unittest.main()

