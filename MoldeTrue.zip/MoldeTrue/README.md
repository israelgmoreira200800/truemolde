# MoldeTrue

Molde em código-fonte do cliente encontrado em `TrueCisco`. Ele mantém a arquitetura útil do programa original sem copiar executáveis, bytecode, logs ou chaves privadas.

O aplicativo é voltado para Windows e faz o seguinte:

- `AltGr` pressionado e solto sozinho: captura o monitor onde está o cursor e envia a imagem à API;
- `Ctrl + Shift + O`: verifica a saúde da API e, se configurado, tenta iniciar o túnel SSH;
- `Ctrl + Shift + Q`: encerra o aplicativo;
- mostra a resposta em uma pequena janela temporária próxima ao cursor;
- permite escolher a matéria por configuração ou por `--subject`.

## Criar uma versão para outra matéria

1. Edite `config.toml` e troque `subject = "nova-materia"` por um identificador como `fisica` ou `quimica-organica`.
2. Confira `base_url` e o contrato da API em `docs/contrato-api.md`.
3. Prepare o ambiente:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1
```

4. Execute como código Python:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run.ps1 -Subject fisica
```

Também é possível executar diretamente:

```powershell
.\.venv\Scripts\python.exe -m molde_true --subject fisica
```

## Túnel SSH opcional

O túnel vem desativado. Para ativá-lo, preencha a seção `[tunnel]` de `config.toml` e informe a chave fora desta pasta:

```powershell
$env:MOLDETRUE_SSH_KEY = 'C:\caminho-seguro\id_ed25519'
```

O host deve existir no arquivo `known_hosts` do usuário. Essa exigência evita aceitar silenciosamente um servidor falso.

## Configuração por ambiente

As variáveis abaixo substituem o TOML:

- `MOLDETRUE_SUBJECT`
- `MOLDETRUE_BASE_URL`
- `MOLDETRUE_DATA_DIR`
- `MOLDETRUE_SAVE_SCREENSHOT`
- `MOLDETRUE_TUNNEL_ENABLED`
- `MOLDETRUE_SSH_HOST`
- `MOLDETRUE_SSH_USER`
- `MOLDETRUE_SSH_KEY`

Capturas não são salvas por padrão. Quando `save_last_screenshot = true`, a última imagem fica no diretório de dados local e continua ignorada pelo Git.

## Estrutura

```text
MoldeTrue/
├── config.toml
├── docs/contrato-api.md
├── scripts/setup.ps1
├── scripts/run.ps1
├── src/molde_true/
│   ├── app.py          # coordenação, filas e ciclo de vida
│   ├── api.py          # contrato HTTP
│   ├── capture.py      # captura e JPEG
│   ├── config.py       # TOML, ambiente e validação
│   ├── hotkeys.py      # atalhos globais do Windows
│   ├── tunnel.py       # encaminhamento SSH opcional
│   └── ui.py           # janela temporária de resposta
└── tests/
```

