$ErrorActionPreference = 'Stop'
$projectDir = Split-Path -Parent $PSScriptRoot
$venvPython = Join-Path $projectDir '.venv\Scripts\python.exe'

if (-not (Test-Path -LiteralPath $venvPython)) {
    py -3 -m venv (Join-Path $projectDir '.venv')
}

& $venvPython -m pip install --disable-pip-version-check -e $projectDir

