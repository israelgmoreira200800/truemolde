param(
    [string]$Subject = ''
)

$ErrorActionPreference = 'Stop'
$projectDir = Split-Path -Parent $PSScriptRoot
$venvPython = Join-Path $projectDir '.venv\Scripts\python.exe'
$configPath = Join-Path $projectDir 'config.toml'

if (-not (Test-Path -LiteralPath $venvPython)) {
    throw 'Ambiente ausente. Execute scripts\setup.ps1 primeiro.'
}

$arguments = @('-m', 'molde_true', '--config', $configPath)
if ($Subject) {
    $arguments += @('--subject', $Subject)
}

& $venvPython @arguments

