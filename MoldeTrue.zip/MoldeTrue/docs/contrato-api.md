# Contrato esperado da API

## Saúde

`GET /health`

Qualquer resposta com status menor que 300 é considerada saudável.

## Resposta da matéria

`POST /answer` com JSON:

```json
{
  "image": "JPEG_EM_BASE64",
  "subject": "nova-materia"
}
```

A API deve responder JSON com a resposta em um dos campos abaixo:

```json
{ "answer": "texto a exibir" }
```

Também são aceitos `resposta`, `question` e `questao` para compatibilidade. Uma resposta HTTP de erro ou um corpo sem esses campos aparece como `ERQ`; falha de captura ou de rede aparece como `ERP`.

O identificador de matéria deve usar letras minúsculas, números e hífens. Exemplos: `fisica`, `quimica-organica`, `historia-2`.

